﻿using System;
using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ClassLibrary.Tests
{
    [TestClass]
    public class PhoneTests
    {
        [TestMethod]
        public void ValidParametersCreatePhone()
        {
            var owner = "anonim";
            var phoneNumber = "123456789";
            var phone = new Phone(owner, phoneNumber);
            Assert.AreEqual(owner, phone.Owner);
            Assert.AreEqual(phoneNumber, phone.PhoneNumber);
            Assert.AreEqual(0, phone.Count);

        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void EmptyOwnerThrowArgumentException()
        {
            var phoneNumber = "123456789";
            var phone = new Phone("", phoneNumber);
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void NullOwneThrowArgumentException()
        {
            var phoneNumber = "123456789";
            var phone = new Phone(null, phoneNumber);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void EmptyPhoneNumberThrowArgumentException()
        {
            var owner = "anonim";
            var phone = new Phone(owner, "");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void NullPhoneNumberThrowArgumentException()
        {
            var owner = "anonim";
            var phone = new Phone(owner, null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void InvalidPhoneNumberThrowArgumentException()
        {
            var owner = "anonim";
            var invalidNumber = "12345";
            var phone = new Phone(owner, invalidNumber);
        }

        [TestMethod]
        public void NewContactReturnTrue()
        {
            var phone = new Phone("anonim", "123456789");
            var contactName = "anonim";
            var contactNumber = "987654321";
            var result = phone.AddContact(contactName, contactNumber);
            Assert.IsTrue(result);
            Assert.AreEqual(1, phone.Count);
        }

        [TestMethod]
        public void DuplicateContactReturnFalseAndNotIncreaseCount()
        {
            var phone = new Phone("anonim", "123456789");
            var contactName = "anonim1";
            var contactNumber = "987654321";
            phone.AddContact(contactName, contactNumber);
            var result = phone.AddContact(contactName, "000000000");
            Assert.IsFalse(result);
            Assert.AreEqual(1, phone.Count);
        }


        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void WhenPhoneBookFulThrowInvalidOperationException()
        {
            var phone = new Phone("anonim", "123456789");
            for (int i = 0; i < phone.PhoneBookCapacity; i++)
            {
                phone.AddContact("Kontakt" + i, "123456789");
            }
            phone.AddContact("ExtraKontakt", "987654321");
        }

        [TestMethod]
        public void ExistingContacReturnCallMessage()
        {
            var phone = new Phone("anonim", "123456789");
            var contactName = "anonim1";
            var contactNumber = "987654321";
            phone.AddContact(contactName, contactNumber);
            var result = phone.Call(contactName);
            Assert.AreEqual($"Calling {contactNumber} ({contactName}) ...", result);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void NonExistingContactThrowInvalidOperationException()
        {
            var phone = new Phone("anonim", "123456789");
            phone.Call("NieistniejącyKontakt");
        }







    }

}    

